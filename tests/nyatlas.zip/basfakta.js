// extract_basfakta_content.js
// Kör med: node extract_basfakta_content.js
// Samlar allt textinnehåll från basfakta-filer i knowledge-mappen

const fs = require("fs").promises;
const path = require("path");

const knowledgeDir = "./knowledge";
const outputFile = "./basfakta_text.txt";

async function run() {
  let output = "";

  let files;
  try {
    files = await fs.readdir(knowledgeDir);
  } catch (err) {
    console.error("Kunde inte läsa knowledge-mappen:", err.message);
    return;
  }

  // Filtrera bara filer med "basfakta_" i namnet och som slutar med .json
  const basfaktaFiles = files
    .filter(f => f.includes("basfakta_") && f.endsWith(".json"))
    .sort();

  for (let i = 0; i < basfaktaFiles.length; i++) {
    const file = basfaktaFiles[i];
    const fullPath = path.join(knowledgeDir, file);

    let raw;
    try {
      raw = await fs.readFile(fullPath, "utf8");
    } catch (err) {
      console.error(`Kunde inte läsa filen ${file}:`, err.message);
      continue;
    }

    let data;
    try {
      data = JSON.parse(raw);
    } catch (e) {
      console.log("Hoppar över icke-JSON:", file);
      continue;
    }

    output += `\n\n===== FIL ${i + 1} / ${basfaktaFiles.length}: ${file} =====\n\n`;

    if (Array.isArray(data.sections)) {
      for (const sec of data.sections) {
        if (sec.title) {
          output += `**${sec.title}**\n`; // Rubrik från sektionen
        }
        if (sec.keywords && sec.keywords.length > 0) {
          output += `Keywords: ${sec.keywords.join(", ")}\n`; // Keywords
        }
        if (sec.text) {
          output += sec.text + "\n"; // Hela textinnehållet
        }
        output += "\n"; // Extra rad mellan sektioner
      }
    }
  }

  try {
    await fs.writeFile(outputFile, output, "utf8");
    console.log(`\n🎯 KLART! Text från ${basfaktaFiles.length} filer sparad i ${outputFile}`);
  } catch (err) {
    console.error("Kunde inte skriva ut filen:", err.message);
  }
}

run();
