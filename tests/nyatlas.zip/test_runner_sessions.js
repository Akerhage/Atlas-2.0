const axios = require('axios');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
require('dotenv').config();

// === INSTÄLLNINGAR ===
const SERVER_URL = 'http://localhost:3001/search_all';
const API_KEY = process.env.CLIENT_API_KEY;
const SUITE_FILE = 'tests/session_hybrid_tools.json'; // Filen med dina scenarion
const LOG_FILE = 'session_test_results.txt';
const DELAY_MS = 1500; // Lite längre paus i sessioner för att låta servern "andas"

// === SEMANTISKA SYNONYMER (Samma lista som i regressionstestet) ===
const TEST_SYNONYMS = {
'behöver gå': ['måste gå', 'krävs', 'genomföra', 'obligatorisk', 'behöver genomföra'],
'obligatorisk': ['krav', 'måste', 'krävs', 'obligatoriskt moment', 'behöver'],
'göra om': ['ta om', 'göra om', 'genomföra på nytt', 'underkänd', 'kuggad'],
'godkänd': ['klara', 'fixa', 'bestå', 'godkänt'],
'14 år och 9 månader': ['14 år och 9 månader', '14,5 år', '14 år 9 mån', '14 år', '14.5'],
'15 år': ['15 år', '15-åring', 'myndig moped'],
'16 år': ['16 år', '16-åring', 'övningsköra bil'],
'17 timmar': ['17 timmar', 'minst 17 timmar'],
'320 minuter': ['320 minuter', '4 x 80 min', 'trafikkörning'],
'80 min': ['80 min', '80 minuter', 'standardlektion', 'en lektion'],
'100 min': ['100 min', '100 minuter', 'dubbel lektion', 'duo'],
'3,5 timmar': ['3.5 timmar', 'tre och en halv timme', '3,5 h'],
'am': ['am', 'moped', 'moped klass 1', 'eu-moped', 'moppe', 'am-kort', 'am-kurs'],
'mc': ['mc', 'motorcykel', 'a-behörighet', 'a1', 'a2', 'tung mc'],
'bil': ['bil', 'personbil', 'b-körkort', 'b-behörighet'],
'automat': ['automat', 'automatväxlad', 'villkor 78', 'kod 78'],
'risk 1': ['risk 1', 'riskettan', 'riskutbildning del 1', 'alkohol och droger', 'riskettan bil', 'riskettan mc'],
'risk 2': ['risk 2', 'risktvåan', 'halkbana', 'halka', 'halkkörning'],
'intro': ['introduktionskurs', 'handledarkurs', 'handledarutbildning', 'handledare'],
'körkortstillstånd': ['tillstånd', 'transportstyrelsen', 'grupp 1'],
'faktura': ['faktura', 'klarna', 'delbetala', 'scancloud', 'resurs bank', 'betala senare'],
'avbokning': ['avbokning', 'avboka', 'omboka', 'återbud'],
'pris': ['pris', 'kostar', 'kostnad', 'avgift', 'kr', 'sek', 'kronor'],
'boka': ['boka', 'bokning', 'reservera', 'anmäla', 'köpa'],
'kontakt': ['kontakt', 'telefon', 'ring', 'maila', 'e-post', 'support', 'kundtjänst']
};

// === NORMALISERING (För att undvika falska fel på stavning/format) ===
function normalizeForComparison(text) {
if (!text) return '';
let normalized = text.toLowerCase().replace(/[^a-zåäöüéè\s\d]/g, ' ').replace(/\s+/g, ' ').trim();

normalized = normalized.replace(/(\d+)\s?år/g, '$1ar');
normalized = normalized.replace(/(\d+)\s?månader/g, '$1manader'); 
normalized = normalized.replace(/tre och en halv timme/g, '3.5 timmar');
normalized = normalized.replace(/(\d+),(\d+)\s?timmar/g, '$1.$2 timmar');

// Specifika fixar
normalized = normalized.replace(/kod 78/g, 'villkor 78');
normalized = normalized.replace(/lån av moppe/g, 'lån av moped');
normalized = normalized.replace(/kvällslektioner/g, 'kväll');
normalized = normalized.replace(/avbokningspolicy/g, 'policy');
normalized = normalized.replace(/halkbanan/g, 'risk 2');
normalized = normalized.replace(/am utbildning/g, 'am kurs');

return normalized;
}

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

async function runSessionTests() {
const suitePath = path.join(__dirname, SUITE_FILE);
if (!fs.existsSync(suitePath)) {
console.error(`❌ Saknas: ${suitePath}`);
return;
}

const scenarios = JSON.parse(fs.readFileSync(suitePath, 'utf8'));
console.log(`🎬 Startar SESSIONSTEST med ${scenarios.length} scenarier...\n`);

// Rensa loggfil
fs.writeFileSync(LOG_FILE, `=== SESSION RESULTAT ${new Date().toLocaleString()} ===\n\n`);

let passedScenarios = 0;
let failedScenarios = 0;

for (const scenario of scenarios) {
console.log(`🔹 SCENARIO: ${scenario.name}`);

// VIKTIGT: En unik session för HELA detta scenario
const sessionId = crypto.randomBytes(16).toString('hex');
let scenarioContext = {}; // Håller klient-sidans context om servern skickar det
let isFirst = true;
let scenarioFailed = false;

// Loopa igenom varje steg i konversationen
for (let i = 0; i < scenario.steps.length; i++) {
const step = scenario.steps[i];
process.stdout.write(`   [Steg ${i+1}] "${step.query}" -> `);

try {
const payload = {
query: step.query,
sessionId: sessionId,
isFirstMessage: isFirst,
context: scenarioContext // Skicka med context om din legacy-motor kräver det
};

const startTime = Date.now();
const res = await axios.post(SERVER_URL, payload, {
headers: { 'x-api-key': API_KEY, 'Content-Type': 'application/json' },
timeout: 20000
});
const duration = Date.now() - startTime;

const rawAnswer = res.data.answer || "";
const normalizedAnswer = normalizeForComparison(rawAnswer);

// Uppdatera context för nästa steg (om servern returnerar det)
if (res.data.new_context) {
scenarioContext = res.data.new_context;
}

// --- VALIDERING ---
const missingExpect = [];
const foundForbidden = [];

// 1. Kolla EXPECT (Måste finnas)
if (step.expect) {
step.expect.forEach(kw => {
const normKw = normalizeForComparison(kw);
let found = normalizedAnswer.includes(normKw);

// Synonym-check
if (!found && TEST_SYNONYMS[kw.toLowerCase()]) {
	found = TEST_SYNONYMS[kw.toLowerCase()].some(syn => 
		normalizedAnswer.includes(normalizeForComparison(syn))
	);
}

if (!found) missingExpect.push(kw);
});
}

// 2. Kolla MISSING (Får INTE finnas) - T.ex. fel stadsnamn
if (step.missing) {
step.missing.forEach(kw => {
const normKw = normalizeForComparison(kw);
if (normalizedAnswer.includes(normKw)) {
	foundForbidden.push(kw);
}
});
}

// --- RESULTAT ---
if (missingExpect.length === 0 && foundForbidden.length === 0) {
console.log(`✅ OK (${duration}ms)`);
} else {
console.log(`❌ FAIL`);
scenarioFailed = true;

// Logga felet tydligt
if (missingExpect.length > 0) console.log(`      Saknade ord: [${missingExpect.join(', ')}]`);
if (foundForbidden.length > 0) console.log(`      Förbjudna ord hittades: [${foundForbidden.join(', ')}]`);
console.log(`      Svar: "${rawAnswer.slice(0, 100)}..."`);

// Skriv till fil
const logEntry = [
`--------------------------------------------------`,
`[FAIL] SCENARIO: ${scenario.name}`,
`STEG ${i+1}: "${step.query}"`,
`SVAR: "${rawAnswer}"`,
`SAKNADE: ${missingExpect.join(', ')}`,
`FÖRBJUDNA: ${foundForbidden.join(', ')}`,
`--------------------------------------------------\n`
].join('\n');
fs.appendFileSync(LOG_FILE, logEntry);
}

isFirst = false; 

} catch (err) {
console.log(`🔥 ERROR: ${err.message}`);
scenarioFailed = true;
fs.appendFileSync(LOG_FILE, `[ERROR] ${scenario.name} - ${err.message}\n`);
}

// Pausa mellan steg i sessionen
await delay(DELAY_MS);
}

if (scenarioFailed) {
failedScenarios++;
console.log(`   ⚠️  Scenario misslyckades.\n`);
} else {
passedScenarios++;
console.log(`   🌟 Scenario klart utan anmärkning.\n`);
}
}

// Summering
const summary = `\n🏁 SESSIONSTEST KLART: ${passedScenarios} Lyckade, ${failedScenarios} Misslyckade\n`;
console.log(summary);
fs.appendFileSync(LOG_FILE, summary);
}

runSessionTests();