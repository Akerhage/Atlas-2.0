const ForceAddEngine = require('./forceAddEngine');

// Simulerad test-query och intent (justera efter ditt scenario)
const queryLower = "risk 1 halkbana";
const intentResult = {
  intent: "risk_course",
  slots: {
    vehicle: null,
    service: null
  }
};
const lockedCity = null;

// Exempel på allChunks (lägg in ditt riktiga allChunks här)
const allChunks = [
  // {id: 1, type: 'basfakta', source: 'basfakta_riskutbildning_bil_mc.json', title: 'Risk 1', text: 'riskettan text', keywords: ['risk 1']},
  // {id: 2, type: 'basfakta', source: 'basfakta_om_foretaget.json', title: 'Företagsinfo', text: 'info om företag', keywords: []},
];

// Skapa engine
const engine = new ForceAddEngine(allChunks);

// Debug: logga allChunks
console.log("\n[DEBUG] allChunks.length =", allChunks.length);
console.log("[DEBUG] allChunks sample =", allChunks.slice(0, 5));

// Override addChunks för att logga varför varje chunk läggs till
const originalAddChunks = engine.addChunks.bind(engine);
engine.addChunks = function(chunks, score, prepend = false) {
  console.log(`\n[DEBUG] addChunks kallad med ${chunks.length} chunk(s), score=${score}, prepend=${prepend}`);
  chunks.forEach(c => {
    const exists = this.mustAddChunks.some(mc => mc.id === c.id);
    console.log(`  - id=${c.id}, source=${c.source}, type=${c.type}, existsAlready=${exists}`);
  });
  const count = originalAddChunks(chunks, score, prepend);
  console.log(`[DEBUG] actually added ${count} chunk(s)`);
  return count;
};

// Kör engine
const result = engine.execute(queryLower, intentResult, lockedCity);

// Debug: resultat
console.log("\n[DEBUG] Result mustAddChunks.length =", result.mustAddChunks.length);
result.mustAddChunks.forEach((c,i) => {
  console.log(`  ${i+1}. id=${c.id}, title=${c.title}, source=${c.source}, type=${c.type}`);
});
console.log("[DEBUG] forceHighConfidence =", result.forceHighConfidence);
