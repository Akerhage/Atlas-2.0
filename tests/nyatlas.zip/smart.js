const fs = require('fs');
const path = require('path');

const KNOWLEDGE_DIR = path.resolve(__dirname, 'knowledge');
const OUTPUT_FILE = path.resolve(__dirname, 'tests', 'suite_basfakta_only.json');

function generateBasfakta() {
    const files = fs.readdirSync(KNOWLEDGE_DIR).filter(f => f.toLowerCase().includes('basfakta') && f.endsWith('.json'));
    let tests = [];

    files.forEach(file => {
        const data = JSON.parse(fs.readFileSync(path.join(KNOWLEDGE_DIR, file), 'utf8'));
        const sections = data.sections || data.critical_answers || [];

        sections.forEach((item, idx) => {
            const title = item.title || (item.match_keywords ? item.match_keywords[0] : null);
            if (title && (item.answer || item.text)) {
                // KORTARE FRÅGA = SNABBARE SVAR = INGEN TIMEOUT
                const question = title.includes('?') ? title : `Vad gäller för ${title.toLowerCase()}?`;
                
                let rawKeys = item.keywords || item.match_keywords || title.split(' ');
                let cleanKeywords = [...new Set(rawKeys)]
                    .map(k => k.toLowerCase().replace(/[.,!?:;]/g, '').trim())
                    .filter(k => k.length > 4); // Bara viktiga, långa ord

                if (cleanKeywords.length > 0) {
                    tests.push({
                        id: `fact_${file.replace('.json','')}_s${idx}`,
                        question: question,
                        required_keywords: cleanKeywords.slice(0, 3), // VIKTIGT: Bara 3 keywords!
                        source_file: file
                    });
                }
            }
        });
    });

    fs.writeFileSync(OUTPUT_FILE, JSON.stringify({ tests }, null, 2));
    console.log(`✅ Skapade ${tests.length} snabba fakta-tester.`);
}
generateBasfakta();