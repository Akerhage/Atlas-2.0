// VIKTIGT: Ingen require behövs i Node v22+
const BASE_URL = 'http://localhost:3001/search_all';
const API_KEY = 'MDA_CHAT_8x9k2mPqR7vT3nL5zW1eJ4fH6gK9'; // Din nyckel

// De 25 frågorna som failar
const failedQuestions = [
    "Vad gäller för steg 8: utbildningskontroll?",
    "Vad gäller för steg 12: prövotiden?",
    "Behöver jag gå kursen för MC eller körning på trafikskola?",
    "Vad gäller för giltighetstid och förlängning?",
    "Vad gäller för ykb grundutbildning (140 timmar)?",
    "Vad gäller för ykb fortbildning (35 timmar)?",
    "Var erbjuder ni lastbilsutbildning (C/CE/YKB)?",
    "Vad är en Prova-på-uppkörning (Utbildningskontroll)?",
    "Hur fungerar Intensivkurs (2 veckor)?",
    "Vad gäller för extra stöd för återfallselever?",
    "Vad ingår i Lektionspaket för MC?",
    "Var erbjuder ni MC-utbildning?",
    "Vad gäller för testlektion för mc (endast inför intensivkurs)?",
    "När är MC-säsongen? (Vinteruppehåll)",
    "Vilka motorcyklar kör ni med?",
    "Vad gäller för hej?",
    "Vad gäller för tack?",
    "Vad gäller för vem är du?",
    "Vad gäller för åldersgräns för b-körkort?",
    "Gäller Riskutbildning för Bil även för MC?",
    "Hur länge är riskutbildningarna giltiga?",
    "Vad gäller för jag förstår inte frågan (fallback)?"
];

async function runTest() {
    console.log("🚀 Startar diagnos av 25 fallerande frågor...\n");

    for (const q of failedQuestions) {
        try {
            // Använder Node v22 inbyggda fetch
            const response = await fetch(BASE_URL, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
                body: JSON.stringify({ query: q, sessionId: 'debug_session_' + Date.now() })
            });
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }

            const data = await response.json();
            
            // Enkel analys
            const answer = data.answer || "INGET SVAR";
            const chunks = data.context ? data.context.length : 0;
            
            // Plocka ut källor säkert
            let sources = "Inga källor";
            if (data.context && Array.isArray(data.context)) {
                // Tar unika källor för att spara plats
                const uniqueSources = [...new Set(data.context.map(c => c.source))];
                sources = uniqueSources.join(', ');
            }
            
            console.log(`--------------------------------------------------`);
            console.log(`F: ${q}`);
            console.log(`S: ${answer.substring(0, 100).replace(/\n/g, ' ')}...`); 
            console.log(`Chunks: ${chunks}`);
            console.log(`Källor: ${sources}`);
            
            // Varning om fallback triggas
            if(answer.includes("Jag kan hjälpa till med det") || answer.includes("hittar ingen information") || answer.includes("Jag förstår inte riktigt")) {
                console.log(`❌ FALLBACK / FEL SVAR`);
            } else {
                console.log(`✅ MATCH (Förmodligen)`);
            }

        } catch (e) {
            console.error(`ERROR på fråga "${q}":`, e.message);
        }
    }
}

runTest();